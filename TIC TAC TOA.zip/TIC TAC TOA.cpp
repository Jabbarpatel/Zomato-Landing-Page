#include<iostream>
using namespace std;
int game(char a[3][3])
{
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
    cout<<" "<<a[0][0]<<"         |      " <<a[0][1]<<"      |       " <<a[0][2]<<"     |     "<<endl;
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
    cout<<" "<<a[1][0]<<"         |      "<<a[1][1]<<"      |       "<<a[1][2]<<"     |     "<<endl;
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
    cout<<"---------------------------------------------------"<<endl;
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
    cout<<" "<<a[2][0]<<"         |      "<<a[2][1]<<"      |       "<<a[2][2]<<"     |     "<<endl;
    cout<<"           |      "<<"       |       "<<"      |      "<<endl;
}
int logic1(char a[3][3],int position)
{
    if(position==1)
    {
        a[0][0]='X';
    }
    else if(position==2)
    {
        a[0][1]='X';
    }
    else if(position==3)
    {
        a[0][2]='X';
    }
    else if(position==4)
    {
        a[1][0]='X';
    }
    else if(position==5)
    {
        a[1][1]='X';
    }
    else if(position==6)
    {
        a[1][2]='X';
    }
    else if(position==7)
    {
        a[2][0]='X';
    }
    else if(position==8)
    {
        a[2][1]='X';
    }
    else if(position==9)
    {
        a[2][2]='X';
    }
}
int logic2(char a[3][3],int position)
{
    if(position==1)
    {
        a[0][0]='O';
    }
    else if(position==2)
    {
        a[0][1]='O';
    }
    else if(position==3)
    {
        a[0][2]='O';
    }
    else if(position==4)
    {
        a[1][0]='O';
    }
    else if(position==5)
    {
        a[1][1]='O';
    }
    else if(position==6)
    {
        a[1][2]='O';
    }
    else if(position==7)
    {
        a[2][0]='O';
    }
    else if(position==8)
    {
        a[2][1]='O';
    }
    else if(position==9)
    {
        a[2][2]='O';
    }
}
int main()
{
    char a[3][3]= {{'1','2','3'},{'4','5','6'},{'7','8','9'}};
    cout<<"------- WELCOME--TO--TIC--TAC--TOE--GAME ------"<<endl;
    cout<<"------- FIRST PLAYER IS X AND SECOND PLAYER IS O ------"<<endl;
    cout<<"PLAYER MUST NEED TO BE ENTER THE POSITION OF VARIABLE(X AND O)"<<endl;
    game(a);
    int i=0,position;
    char input;
    while(i<=9)
    {
        if(i%2==0)
        {
            cout<<"PLAYER X PLEASE ENTER YOUR INPUT"<<endl;
        }
        else
        {
            cout<<"PLAYER O PLEASE ENTER YOUR INPUT"<<endl;
        }
        if(i==0)
        {
            cin>>position;
            logic1(a,position);
            game(a);
        }
        else if(i==1)
        {
            cin>>position;
            logic2(a,position);
            game(a);
        }
        else if(i==2)
        {
            cin>>position;
            logic1(a,position);
            game(a);
        }
        else if(i==3)
        {
            cin>>position;
            logic2(a,position);
            game(a);
        }
        if(i==4)
        {
            cin>>position;
            logic1(a,position);
            game(a);
        }
        else if(i==5)
        {
            cin>>position;
            logic2(a,position);
            game(a);
        }
        else if(i==6)
        {
            cin>>position;
            logic1(a,position);
            game(a);
        }
        else if(i==7)
        {
            cin>>position;
            logic2(a,position);
            game(a);
        }
        else if(i==8)
        {
            cin>>position;
            logic1(a,position);
            game(a);
        }
        else if(i==9)
        {
            cout<<"THE MATCH IS TIE"<<endl;
            break;
        }
        i++;
        if(i>1)
        {
            if((a[0][0]=='X')&&(a[0][1]=='X')&&(a[0][2]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[1][0]=='X')&&(a[1][1]=='X')&&(a[1][2]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[2][0]=='X')&&(a[2][1]=='X')&&(a[2][2]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else  if((a[0][0]=='O')&&(a[0][1]=='O')&&(a[0][2]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[1][0]=='O')&&(a[1][1]=='O')&&(a[1][2]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[2][0]=='O')&&(a[2][1]=='O')&&(a[2][2]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[0][0]=='X')&&(a[1][1]=='X')&&(a[2][2]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[0][2]=='X')&&(a[1][1]=='X')&&(a[2][0]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[0][0]=='X')&&(a[1][0]=='X')&&(a[2][0]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[0][1]=='X')&&(a[1][1]=='X')&&(a[2][1]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[0][2]=='X')&&(a[1][2]=='X')&&(a[2][2]=='X'))
            {
                cout<<"PLAYER X IS WON"<<endl;
                break;
            }
            else if((a[0][0]=='O')&&(a[1][1]=='O')&&(a[2][2]=='X'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[0][2]=='O')&&(a[1][1]=='O')&&(a[2][0]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[0][0]=='O')&&(a[1][0]=='O')&&(a[2][0]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[0][1]=='O')&&(a[1][1]=='O')&&(a[2][1]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
            else if((a[0][2]=='O')&&(a[1][2]=='O')&&(a[2][2]=='O'))
            {
                cout<<"PLAYER O IS WON"<<endl;
                break;
            }
        }
    }
    return 0;
}

